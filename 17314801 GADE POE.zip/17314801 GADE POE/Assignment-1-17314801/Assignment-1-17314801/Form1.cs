﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_1_17314801
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        GameEngine engine = new GameEngine();

        private void button1_Click(object sender, EventArgs e)
        {
            tmrSim.Enabled = true;
            btnStart.Enabled = false;
            btnStop.Enabled = true;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to leave?", "Exit Game", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
                Application.Exit();
        }

        private void lblMap_Click(object sender, EventArgs e)
        {
            int mouseXPos = MousePosition.X;
            int mouseYPos = MousePosition.Y;

            int formX = this.Location.X;
            int formY = this.Location.Y;

            int y = (mouseXPos - formX - 39 - 6) / 15;
            int x = (mouseYPos - formY - 70 - 1) / 15;

            txtDisplay.Text = "";
            foreach (Unit k in engine.map.UnitsOnMap)
            {
                if (k.X == x && k.Y == y)
                {
                    txtDisplay.Text += k.toString();
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tmrSim.Enabled = false;
        }

        private void tmrSim_Tick(object sender, EventArgs e)
        {
            lblTimer.Text = System.DateTime.Now.ToLongTimeString();

            engine.start();

            //show grid
            lblMap.Text = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    lblMap.Text += engine.map.grid[i, j] + " ";
                }
                lblMap.Text += "\n";
            }
        }
    }
}
