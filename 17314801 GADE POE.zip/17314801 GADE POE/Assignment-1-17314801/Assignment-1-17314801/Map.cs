﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1_17314801
{
    class Map
    {
        private const int MAX_RANDOM_UNITS = 50;
        public const string FIELD_SYMBOL = ".";
        public string[,] grid = new string[20, 20];
        private List<Unit> unitsonMap = new List<Unit>();
        private int numberofUnitsOnMap = 0;

        public string[,] Grid
        {
            get
            {
                return grid;
            }
        }

        public List<Unit> UnitsOnMap
        {
            get
            {
                return unitsonMap;
            }
        }

        public void populate()
        {
            Random rnd = new Random();
            int numberRandomUnits = rnd.Next(0, MAX_RANDOM_UNITS) + 1;
            int x, y, randomAttackRange;
            bool attackOption;
            string team;

            //clear Field
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    grid[i, j] = FIELD_SYMBOL;
                }
            }

            for (int k = 1; k <= numberRandomUnits; k++)
            {
                //Ensure XP, YP is not occupied by another unit
                do
                {
                    x = rnd.Next(0, 20);
                    y = rnd.Next(0, 20);
                } while (grid[x, y] != FIELD_SYMBOL);

                //generate randomly either a MeleeUnit or RangedUnit and place on map
                if (rnd.Next(1, 3) == 1)
                {
                    attackOption = rnd.Next(0, 2) == 1 ? true : false;        //Randomize the units attack options
                    team = rnd.Next(0, 2) == 1 ? "BLUE" : "RED";
                    Unit tmp = new MeleeUnit(x, y, 100, -1, attackOption, 1, team, "M");
                    unitsonMap.Add(tmp);


                    grid[x, y] = tmp.Symbol;



                    //update the arraySize
                    numberofUnitsOnMap++;
                }
                else
                {
                    attackOption = rnd.Next(0, 2) == 1 ? true : false;
                    randomAttackRange = rnd.Next(1, 20);
                    team = rnd.Next(0, 2) == 1 ? "BLUE" : "RED";
                    Unit tmp = new RangedUnit(x, y, 100, -1, attackOption, randomAttackRange, team, "R");
                    unitsonMap.Add(tmp);

                    grid[x, y] = unitsonMap[numberofUnitsOnMap].Symbol;

                    //update the arraySize
                    numberofUnitsOnMap++;
                }
            }

        }

        private void moveOnMap(Unit k, int newXPos, int newYPos)
        {
            grid[k.X, k.Y] = FIELD_SYMBOL;
            grid[newXPos, newYPos] = k.Symbol;
        }

        public void update(Unit k, int newXPos, int newYPos)
        {
            if ((newXPos >= 0 && newXPos < 20) && (newYPos >= 0 && newYPos < 20))
            {
                moveOnMap(k, newXPos, newYPos);
                k.Movement(newXPos, newYPos);
            }
        }

        public void checkHealth()
        {
            for (int i = 0; i < numberofUnitsOnMap; i++)
            {
                if (!unitsonMap[i].UnitAlive())
                {
                    grid[unitsonMap[i].X, unitsonMap[i].Y] = FIELD_SYMBOL;  //remove the unit from the grid
                    unitsonMap.RemoveAt(i);          //remove the unit from the list
                    numberofUnitsOnMap--;
                }
            }
        }
    }
}