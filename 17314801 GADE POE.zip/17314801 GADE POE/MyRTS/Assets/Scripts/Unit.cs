﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

namespace MyRTS
{
    abstract class Unit : MonoBehaviour //Parent class Unit, with child class RTSGame
    {
        protected int x;
        protected int y;
        protected int hp;
        protected int speed;
        protected int attackRange;
        protected bool attack;
        protected string faction;
        protected string symbol;
        protected string name;

        //Constructor
        public Unit(int x, int y, int hp, int speed, bool attack, int attackRange, string faction, string symbol, string name)    //Creating 
        {
            this.x = x;
            this.y = y;
            this.hp = hp;
            this.speed = speed;
            this.attack = attack;
            this.attackRange = attackRange;
            this.faction = faction;
            this.symbol = symbol;
            this.name = name;
        }

        //destructor
        ~Unit()
        {
        }

        //Accessors 
        public int X
        {
            get { return x; }
            set { x = value; }
        }

        public int Y
        {
            get { return y; }
            set { y = value; }
        }

        public int Health
        {
            get { return hp; }
            set { hp = value; }
        }

        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }

        public bool Attack
        {
            get { return attack; }
            set { attack = value; }
        }

        public int AttackRange
        {
            get { return attackRange; }
            set { attackRange = value; }
        }

        public string Faction
        {
            get { return faction; }
            set { faction = value; }
        }

        public string Symbol
        {
            get { return symbol; }
            set { symbol = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public abstract Unit NearestUnit(List<Unit> k);
        public abstract void Movement(int xpos, int ypos);
        public abstract void combat(Unit enemy);
        public abstract bool UnitWithinAttackRange(Unit enemy);
        public abstract bool UnitAlive();

        public virtual void save()
        {

        }
    }
}

