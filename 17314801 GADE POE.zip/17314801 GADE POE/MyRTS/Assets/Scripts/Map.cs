﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;
using System.Linq;
using System.Text;
using System.Threading;

namespace MyRTS
{
    class Map
    {
        private const int MAX_RANDOM_UNITS = 50;
        private const int MAX_RANDOM_BUILDINGS = 30;
        private const string FIELD_SYMBOL = ".";
        private string[,] grid = new string[20, 20];
        private List<Unit> unitsonMap = new List<Unit>();
        private int numberofUnitsOnMap = 0;
        private List<Building> buildingsonMap = new List<Building>();
        private int numberofBuildingsOnMap = 0;

        public string[,] Grid
        {
            get
            {
                return grid;
            }
        }

        public List<Unit> UnitsOnMap
        {
            get
            {
                return unitsonMap;
            }
        }

        public List<Building> BuildingsOnMap
        {
            get
            {
                return buildingsonMap;
            }
        }

        public void clearField()
		{
			for (int i = 0; i < 20; i++) {
				for (int j = 0; j < 20; j++) {
					grid [i, j] = FIELD_SYMBOL;
				}
			}
		}

        private void moveOnMap(Unit k, int newXPos, int newYPos)
        {
            grid[k.X, k.Y] = FIELD_SYMBOL;
            grid[newXPos, newYPos] = k.Symbol;
        }

        public void update(Unit k, int newXPos, int newYPos)
        {
            if ((newXPos >= 0 && newXPos < 20) && (newYPos >= 0 && newYPos < 20))
            {
                moveOnMap(k, newXPos, newYPos);
                k.Movement(newXPos, newYPos);
            }
        }

		public void populate()
		{
			Random rnd = new Random();
			int numberRandomUnits = rnd.Next(0, MAX_RANDOM_UNITS) + 1;
			int x, y, randomAttackRange;
			bool attackOption;
			string team;

			//clear Field
			clearField();

			for (int k = 1; k <= numberRandomUnits; k++)
			{
				//Ensure XP, YP is not occupied by another unit
				do
				{
					x = rnd.Next(0, 20);
					y = rnd.Next(0, 20);
				} while (grid[x, y] != FIELD_SYMBOL);

				//generate randomly either a MeleeUnit or RangedUnit and place on map
				if (rnd.Next(1, 3) == 1)
				{
					attackOption = rnd.Next(0, 2) == 1 ? true : false;        //Randomize the units attack options
					team = rnd.Next(0, 2) == 1 ? "BLUE" : "RED";
					Unit tmp = new MeleeUnit(x, y, 100, -1, attackOption, 1, team, "M", "Foot Soldier");
					unitsonMap.Add(tmp);


					grid[x, y] = tmp.Symbol;



					//update the arraySize
					numberofUnitsOnMap++;
				}
				else
				{
					attackOption = rnd.Next(0, 2) == 1 ? true : false;
					randomAttackRange = rnd.Next(1, 20);
					team = rnd.Next(0, 2) == 1 ? "BLUE" : "RED";
					Unit tmp = new RangedUnit(x, y, 100, -1, attackOption, randomAttackRange, team, "R", "Archer");
					unitsonMap.Add(tmp);

					grid[x, y] = unitsonMap[numberofUnitsOnMap].Symbol;

					//update the arraySize
					numberofUnitsOnMap++;
				}
			}
			populateBuildings();
		}

		public void populateBuildings()
		{
			Random rnd = new Random();
			int numberRandomBuildings = rnd.Next(0, MAX_RANDOM_BUILDINGS) + 1;
			int x, y;
			string team;

			for (int k = 1; k <= numberRandomBuildings; k++)
			{
				//Ensure XP, YP is not occupied by another unit
				do
				{
					x = rnd.Next(0, 20);
					y = rnd.Next(0, 20);
				} while (grid[x, y] != FIELD_SYMBOL);

				//generate randomly either a MeleeUnit or RangedUnit and place on map
				if (rnd.Next(1, 3) == 1)
				{ 
					team = rnd.Next(0, 2) == 1 ? "BLUE" : "RED";
					ResourceBuilding tmp = new ResourceBuilding(x, y, 100, team, "RB", "Gold", 4, 0);
					buildingsonMap.Add(tmp);


					grid[x, y] = tmp.Symbol;



					//update the arraySize
					numberofBuildingsOnMap++;
				}
				else
				{
					team = rnd.Next(0, 2) == 1 ? "BLUE" : "RED";
					FactoryBuilding tmp = new FactoryBuilding(x, y, 100, team,"FB", 1, 0, 0, 0);
					buildingsonMap.Add(tmp);

					grid[x, y] = buildingsonMap[numberofBuildingsOnMap].Symbol;

					//update the arraySize
					numberofBuildingsOnMap++;
				}
			}

		}

        public void checkHealth()
        {
            for (int i = 0; i < numberofUnitsOnMap; i++)
            {
                if (!unitsonMap[i].UnitAlive())
                {
                    grid[unitsonMap[i].X, unitsonMap[i].Y] = FIELD_SYMBOL;  //remove the unit from the grid
                    unitsonMap.RemoveAt(i);          //remove the unit from the list
                    numberofUnitsOnMap--;
                }
            }
        }

        public void checkbuildingHealth()
        {
            for (int i = 0; i < numberofBuildingsOnMap; i++)
            {
                if (!buildingsonMap[i].isAlive())
                {
                    grid[buildingsonMap[i].X, buildingsonMap[i].Y] = FIELD_SYMBOL;  //remove the unit from the grid
                    buildingsonMap.RemoveAt(i);          //remove the unit from the list
                    numberofBuildingsOnMap--;
                }
            }
        }

        public void saveMap()
        {
            try
            {
                File.Delete(@"C:\Users\17314801\Documents\Visual Studio 2015\Projects\Assignment-2-17314801\Assignment-2-17314801\bin\Debug\Files\MeleeUnit.txt");
                File.Delete(@"C:\Users\17314801\Documents\Visual Studio 2015\Projects\Assignment-2-17314801\Assignment-2-17314801\bin\Debug\Files\RangedUnit.txt");
                foreach (Unit u in unitsonMap)
                {
                    u.save();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            try
            {
                File.Delete(@"C:\Users\17314801\Documents\Visual Studio 2015\Projects\Assignment-2-17314801\Assignment-2-17314801\bin\Debug\Files\ResourceBuilding.txt");
                File.Delete(@"C:\Users\17314801\Documents\Visual Studio 2015\Projects\Assignment-2-17314801\Assignment-2-17314801\bin\Debug\Files\FactoryBuilding.txt");
                foreach (Building b in BuildingsOnMap)
                {
                    b.save();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public bool loadMap()
        {
            bool success = true;
            string input;
            int x;
            int y;
            int health;
            int speed;
            bool attack;
            int attackRange;
            string faction;
            string symbol;
            string name;
            int resourcePerTick;
            int resourcesRemaining;
            string resourceType;
            int unitsToProduce;
            int gameTicksPerProduction;
            int spawnPointX;
            int spawnPointY;

            clearField();

            try
            {
                FileStream inFile = new FileStream(@"C:\Users\17314801\Documents\Visual Studio 2015\Projects\Assignment-2-17314801\Assignment-2-17314801\bin\Debug\Files\MeleeUnit.txt", FileMode.Open, FileAccess.Read);              StreamReader reader = new StreamReader(inFile);
                input = reader.ReadLine();
                while (input != null)
                {
                    x = int.Parse(input);
                    y = int.Parse(reader.ReadLine());
                    health = int.Parse(reader.ReadLine());
                    speed = int.Parse(reader.ReadLine());
                    attack = bool.Parse(reader.ReadLine());
                    attackRange = int.Parse(reader.ReadLine());
                    faction = reader.ReadLine();
                    symbol = reader.ReadLine();
                    name = reader.ReadLine();
                    MeleeUnit mU = new MeleeUnit(x, y, health, speed, attack, attackRange, faction, symbol, name);
                    unitsonMap.Add(mU);

                    grid[x, y] = mU.Symbol;

                    //update arraysize
                    numberofUnitsOnMap++;
                    input = reader.ReadLine();
                }
                reader.Close();
                inFile.Close();
            }

            catch (Exception e)
            {
                success = false;
                Console.WriteLine(e);
            }

            try
            {
                FileStream inFile = new FileStream(@"C:\Users\17314801\Documents\Visual Studio 2015\Projects\Assignment-2-17314801\Assignment-2-17314801\bin\Debug\Files\RangedUnit.txt", FileMode.Open, FileAccess.Read);
                StreamReader reader = new StreamReader(inFile);
                input = reader.ReadLine();
                while (input != null)
                {
                    x = int.Parse(input);
                    y = int.Parse(reader.ReadLine());
                    health = int.Parse(reader.ReadLine());
                    speed = int.Parse(reader.ReadLine());
                    attack = bool.Parse(reader.ReadLine());
                    attackRange = int.Parse(reader.ReadLine());
                    faction = reader.ReadLine();
                    symbol = reader.ReadLine();
                    name = reader.ReadLine();
                    RangedUnit rU = new RangedUnit(x, y, health, speed, attack, attackRange, faction, symbol, name);
                    unitsonMap.Add(rU);

                    grid[x, y] = rU.Symbol;

                    //update arraysize
                    numberofUnitsOnMap++;
                    input = reader.ReadLine();
                }
                reader.Close();
                inFile.Close();
            }

            catch (Exception e)
            {
                success = false;
                Console.WriteLine(e);
            }
            try
            {
                FileStream inFile = new FileStream(@"C:\Users\17314801\Documents\Visual Studio 2015\Projects\Assignment-2-17314801\Assignment-2-17314801\bin\Debug\Files\ResourceBuilding.txt", FileMode.Open, FileAccess.Read);
                StreamReader reader = new StreamReader(inFile);
                input = reader.ReadLine();
                while (input != null)
                {
                    x = int.Parse(input);
                    y = int.Parse(reader.ReadLine());
                    health = int.Parse(reader.ReadLine());
                    faction = reader.ReadLine();
                    symbol = reader.ReadLine();
                    resourceType = reader.ReadLine();
                    resourcePerTick = int.Parse(reader.ReadLine());
                    resourcesRemaining = int.Parse(reader.ReadLine());            
                    ResourceBuilding rB = new ResourceBuilding(x, y, health, faction, symbol, resourceType, resourcePerTick, resourcesRemaining);
                    buildingsonMap.Add(rB);

                    grid[x, y] = rB.Symbol;

                    //update arraysize
                    numberofBuildingsOnMap++;
                    input = reader.ReadLine();
                }
                reader.Close();
                inFile.Close();
            }

            catch (Exception e)
            {
                success = false;
                Console.WriteLine(e);
            }
            try
            {
                FileStream inFile = new FileStream(@"C:\Users\17314801\Documents\Visual Studio 2015\Projects\Assignment-2-17314801\Assignment-2-17314801\bin\Debug\Files\FactoryBuilding.txt", FileMode.Open, FileAccess.Read);
                StreamReader reader = new StreamReader(inFile);
                input = reader.ReadLine();
                while (input != null)
                {
                    x = int.Parse(input);
                    y = int.Parse(reader.ReadLine());
                    health = int.Parse(reader.ReadLine());
                    faction = reader.ReadLine();
                    symbol = reader.ReadLine();
                    unitsToProduce = int.Parse(reader.ReadLine());
                    gameTicksPerProduction = int.Parse(reader.ReadLine());
                    spawnPointX = int.Parse(reader.ReadLine());
                    spawnPointY = int.Parse(reader.ReadLine());

                    FactoryBuilding fB = new FactoryBuilding(x, y, health, faction, symbol, unitsToProduce, gameTicksPerProduction, spawnPointX, spawnPointY);
                    buildingsonMap.Add(fB);

                    grid[x, y] = fB.Symbol;

                    //update arraysize
                    numberofBuildingsOnMap++;
                    input = reader.ReadLine();
                }
                reader.Close();
                inFile.Close();
            }

            catch (Exception e)
            {
                success = false;
                Console.WriteLine(e);
            }
            return success;
        }
    }
}


