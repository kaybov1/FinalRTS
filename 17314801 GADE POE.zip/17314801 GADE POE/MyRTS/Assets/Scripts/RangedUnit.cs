﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;

namespace MyRTS
{
    class RangedUnit : Unit //Child class RangedUnit with parent class, unit
    {
        private const int Damage = 2;
        //Constructor
        public RangedUnit(int x, int y, int health, int speed, bool attack, int attackRange, string faction, string symbol, string name)
            : base(x, y, health, speed, attack, attackRange, faction, symbol, name)
        {
        }

        public override void Movement(int x, int y)
        {
            if (x >= 0 && x < 20)
                X = x;
            if (y >= 0 && y < 20)
                Y = y;
        }

        public override void combat(Unit enemy)
        {
            if (this.UnitWithinAttackRange(enemy))
            {
                enemy.Health -= Damage;
            }
        }

        public override bool UnitWithinAttackRange(Unit enemy)
        {
            if ((Math.Abs(this.X - enemy.X) <= this.AttackRange) || (Math.Abs(this.X - enemy.X) <= this.AttackRange))
                return true;
            else
                return false;
        }

        public override Unit NearestUnit(List<Unit> list)
        {
            Unit closest = null;
            int ARXP, ARYP;
            int shortestRange = 3000;

            foreach (Unit k in list)
            {
                ARXP = Math.Abs(this.X - k.X);
                ARYP = Math.Abs(this.Y - k.Y);

                if (ARXP < shortestRange)
                {
                    shortestRange = ARXP;
                    closest = k;
                }
                if (ARYP < shortestRange)
                {
                    shortestRange = ARYP;
                    closest = k;
                }
            }
            return closest;
        }
        public override bool UnitAlive()
        {
            if (this.Health <= 0)
                return false;
            else
                return true;
        }

        public override void save()
        {
            FileStream outFile = null;
            StreamWriter writer = null;
            try
            {
                outFile = new FileStream(@"Files\RangedUnit.txt", FileMode.Append, FileAccess.Write);
                writer = new StreamWriter(outFile);
                writer.WriteLine(x);
                writer.WriteLine(y);
                writer.WriteLine(Health);
                writer.WriteLine(Speed);
                writer.WriteLine(attack);
                writer.WriteLine(attackRange);
                writer.WriteLine(faction);
                writer.WriteLine(symbol);
                writer.WriteLine(name);
                writer.Close();
                outFile.Close();
            }
            catch (IOException fe)
            {
                Console.WriteLine("IOException: " + fe.Message);
            }
            finally
            {
                if (outFile != null)
                    outFile.Close();
                if (writer != null)
                    writer.Close();
            }
        }
    }
}
