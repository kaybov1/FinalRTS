﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;

namespace MyRTS
{
    class ResourceBuilding : Building
    {
        private string resourceType;
        private int resourcePerTick;
        private int resourcesRemaining;

        public string ResourceType
        {
            get { return resourceType; }
            set { resourceType = value; }
        }

        public int ResourcePerTick
        {
            get { return resourcePerTick; }
            set { resourcePerTick = value; }
        }

        public int ResourcesRemaining
        {
            get { return resourcesRemaining; }
            set { resourcesRemaining = value; }
        }

        public ResourceBuilding(int x, int y, int health, string faction, string symbol, string resourceType, int resourcePerTick, int resourcesRemaining)
            : base(x, y, health, faction, symbol)
        {
            this.resourceType = resourceType;
            this.resourcePerTick = resourcePerTick;
            this.resourcesRemaining = resourcesRemaining;
        }

        public override bool isAlive()
        {
            if (this.Health <= 0)
                return false;
            else
                return true;
        }
			

        public void generateResources()
        {
            if (resourcesRemaining >= 0)
                resourcesRemaining -= resourcePerTick;
        }

        public override void save()
        {
            FileStream outFile = null;
            StreamWriter writer = null;
            try
            {
                outFile = new FileStream(@"Files\ResourceBuilding.txt", FileMode.Append, FileAccess.Write);
                writer = new StreamWriter(outFile);
                writer.WriteLine(x);
                writer.WriteLine(y);
                writer.WriteLine(Health);
                writer.WriteLine(faction);
                writer.WriteLine(symbol);
                writer.WriteLine(resourceType);
                writer.WriteLine(ResourcePerTick);
                writer.WriteLine(resourcesRemaining);
                writer.Close();
                outFile.Close();
            }
            catch (IOException fe)
            {
                Console.WriteLine("IOException: " + fe.Message);
            }
            finally
            {
                if (outFile != null)
                    outFile.Close();
                if (writer != null)
                    writer.Close();
            }
        }
    }
}

