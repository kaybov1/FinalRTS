﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class CamerMovement : MonoBehaviour
{
	public Transform map;
	public float speed;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () 
	{        //follower of the camera
		//transform.poisition = Vector2.Lerp (transform.position, map.position);
	}
}
