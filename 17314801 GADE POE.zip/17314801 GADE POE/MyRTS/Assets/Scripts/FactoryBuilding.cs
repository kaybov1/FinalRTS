﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;

namespace MyRTS
{
    class FactoryBuilding : Building
    {
        private int unitsToProduce;
        private int gameTicksPerProduction;
        private int spawnPointX;
        private int spawnPointY;

        public FactoryBuilding(int x, int y, int health, string faction, string symbol, int unitsToProduce, int gameTicksPerProduction, int spawnPointX, int spawnPointY)
            : base(x, y, health, faction, symbol)
        {
            this.unitsToProduce = unitsToProduce;
            this.gameTicksPerProduction = gameTicksPerProduction;
            this.spawnPointX = spawnPointX;
            this.spawnPointY = spawnPointY;
        }

        public override bool isAlive()
        {
            if (this.Health <= 0)
                return false;
            else
                return true;
        }
			

        public int UnitToProduction
        {
            get { return unitsToProduce; }
            set { unitsToProduce = value; }
        }

        public int GameTicksPerProduction
        {
            get { return gameTicksPerProduction; }
            set { gameTicksPerProduction = value; }
        }

        public int SpawnPointX
        {
            get { return spawnPointX; }
            set { spawnPointX = value; }
        }

        public int SpawnPointY
        {
            get { return spawnPointY; }
            set { spawnPointY = value; }
        }

        /*public Unit spawnNewUnit()
        {
            if (unitsToProduce > 0)
            {
                Random rnd = new Random();
                if (rnd(0, 2) == 0)
                {
                    //MeleeUnit
                    MeleeUnit mU = new MeleeUnit(x, y, 100, -1, true, 1, "BLUE", "M", "Club");
                    unitsToProduce--;
                    return mU;
                }
                else
                {
                    //RangedUnit
                    RangedUnit rU = new RangedUnit(x, y, 100, -1, true, 3, "RED", "R", "Club");
                    unitsToProduce--;
                    return rU;
                }
            }
            return null; 
        } */

        public override void save()
        {
            FileStream outFile = null;
            StreamWriter writer = null;
            try
            {
                outFile = new FileStream(@"Files\FactoryBuilding.txt", FileMode.Append, FileAccess.Write);
                writer = new StreamWriter(outFile);
                writer.WriteLine(x);
                writer.WriteLine(y);
                writer.WriteLine(Health);
                writer.WriteLine(faction);
                writer.WriteLine(symbol);
                writer.WriteLine(unitsToProduce);
                writer.WriteLine(gameTicksPerProduction);
                writer.WriteLine(spawnPointX);
                writer.WriteLine(spawnPointY);
                writer.Close();
                outFile.Close();
            }
            catch (IOException fe)
            {
                Console.WriteLine("IOException: " + fe.Message);
            }
            finally
            {
                if (outFile != null)
                    outFile.Close();
                if (writer != null)
                    writer.Close();
            }
        }
    }
}