﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2_17314801
{
    class GameEngine
    {
        public Map map = new Map();

        public GameEngine()
        {
        }

        public void GameObject()
        {

        }

        public void start()
        {
            int newXPos, newYPos;
            Unit closest;

            //update units on map
            map.checkHealth();

            //combat
            for (int j = 0; j < map.UnitsOnMap.Count; j++)
            {

                //Limits of the Game
                if (!map.UnitsOnMap[j].Attack)
                {
                    closest = map.UnitsOnMap[j].NearestUnit(map.UnitsOnMap);
                    if (map.UnitsOnMap[j].X < closest.X)
                        newXPos = map.UnitsOnMap[j].X + 1;
                    else if (map.UnitsOnMap[j].X > closest.X)
                        newXPos = map.UnitsOnMap[j].X - 1;
                    else
                        newXPos = map.UnitsOnMap[j].X;

                    if (map.UnitsOnMap[j].Y < closest.Y)
                        newYPos = map.UnitsOnMap[j].Y + 1;
                    else if (map.UnitsOnMap[j].Y > closest.Y)
                        newYPos = map.UnitsOnMap[j].Y - 1;
                    else
                        newYPos = map.UnitsOnMap[j].Y;
                    map.update(map.UnitsOnMap[j], newXPos, newYPos);
                }

                if (map.UnitsOnMap[j].Attack)
                {
                    for (int i = 0; i < map.UnitsOnMap.Count; i++)
                    {
                        if (map.UnitsOnMap[j].Faction != map.UnitsOnMap[i].Faction)
                            map.UnitsOnMap[j].combat(map.UnitsOnMap[i]);
                    }
                }

                if (!map.UnitsOnMap[j].Attack)
                {
                    for (int i = 0; i < map.UnitsOnMap.Count; i++)
                    {
                        if ((map.UnitsOnMap[j].Faction != map.UnitsOnMap[i].Faction) && (map.UnitsOnMap[j].Faction != map.UnitsOnMap[i].Faction))
                            map.UnitsOnMap[j].Attack = true;
                    }
                }

                if (map.UnitsOnMap[j].Health < 25)
                {
                    newXPos = map.UnitsOnMap[j].X + 1;
                    newYPos = map.UnitsOnMap[j].Y - 1;
                    map.update(map.UnitsOnMap[j], newXPos, newYPos);
                }
            }
        }
    }
}
