﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Assignment_2_17314801
{

    public partial class Form1 : Form 
    {
        public Form1()
        {
            InitializeComponent();
        }

        GameEngine engine = new GameEngine();

        private void Form1_Load(object sender, EventArgs e)
        {
            tmrSim.Enabled = false;
            System.Windows.Forms.DialogResult result = MessageBox.Show("Would you like to load an old game?", "Load Game", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
                engine.map.loadMap();
            else
                engine.map.populate();
        }

        private void tmrSim_Tick(object sender, EventArgs e)
        {
            lblTimer.Text = System.DateTime.Now.ToLongTimeString();

            engine.start();

            //show grid
            lblMap.Text = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    lblMap.Text += engine.map.Grid[i, j] + " ";
                }
                lblMap.Text += "\n";
            }
        }


        private void btnStart_Click(object sender, EventArgs e)
        {
            tmrSim.Enabled = true;
            btnStart.Enabled = false;
            btnStop.Enabled = true;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            tmrSim.Enabled = false;
            btnStop.Enabled = false;
            btnStart.Enabled = true;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Would you like to save the game?", "Exit Game", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                engine.map.saveMap();    
            }
            Application.Exit();
        }

        private void lblMap_Click(object sender, EventArgs e)
        {
            int mouseXPos = MousePosition.X;
            int mouseYPos = MousePosition.Y;

            int formX = this.Location.X;
            int formY = this.Location.Y;

            int y = (mouseXPos - formX - 39 - 6) / 15;
            int x = (mouseYPos - formY - 70 - 1) / 15;

            txtDisplay.Text = "";
            foreach (Unit k in engine.map.UnitsOnMap)
            {
                if (k.X == x && k.Y == y)
                {
                    txtDisplay.Text += k.toString();
                }
            }
        }
    }
}
